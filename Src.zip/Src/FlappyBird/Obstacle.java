package FlappyBird;

import org.joml.Vector3f;

import Game.Core.Node2D;

public class Obstacle extends Node2D{
    protected Pipe top=new Pipe(),bottom=new Pipe();
    protected float speed=0.003f;

    @Override
    public void _ready(){
        addChild(top);
        addChild(bottom);
        bottom.setLocalRotationDegrees(180);
        top.setLocalPosition(new Vector3f(0.0f,3.0f,0.0f));
        bottom.setLocalPosition(new Vector3f(0.0f,-3.0f,0.0f));
        bottom.setLocalScale(new Vector3f(5.0f));
        top.setLocalScale(new Vector3f(5.0f));

    }

    @Override
    public void _update(float _delta){
        // System.out.println(getLocalPosition().add(-speed*_delta,0.0f,0.0f));
        // System.out.println(getGlobalPosition());

    }

    public void set(){
        
    }



}
