package Game;


import org.joml.Vector3f;

import FlappyBird.FlappyBirdEntry;
import Game.Cameras.Nodes.Camera2D;
import Game.Core.Node;
import Game.Physics.Nodes.RigidBody2D;
import Game.Visuals.Nodes.AnimatedSprite2D;
import Game.Visuals.Nodes.ColorRect2D;


public class NodeLoader extends Node{
    
    public NodeLoader(){
        super();
    }

    FlappyBirdEntry entry = new FlappyBirdEntry();

    public void _ready(){
        addChild(entry);
        
    }
    float time=0;

    public void _update(float _delta){
        // System.out.println(rigid.getBodyResource().getPosition());
    }


    protected void _enterTree(){
    }
}
