package CodeNameNeutronStar.Menu;

public class MenuInterface {
    


    


}
